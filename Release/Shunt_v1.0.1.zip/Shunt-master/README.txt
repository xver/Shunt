
TITLE: 1. Introduction


Welcome to the SystemVerilog TCP/IP "Shunt" !

icshunt.help@gmail.com


The Shunt is Open Source Client/Server TCP/IP socket based communication library for SystemVerilog simulation.

    -It aims to enable quick and easy development of communication between stand-alone SystemVerilog simulations and/or external applications

    -It provides a common SystemVerilog/C API and supports mostly all System Verilog data types and data structures.


Tne Shunt is available under a "MIT" License. It can be used without restriction in an open-source or commercial application.


 ============================================================================
 Copyright (c) 2016-2017 IC Verimeter. All rights reserved.  
============================================================================= 